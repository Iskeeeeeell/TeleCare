<?php
// config.php - Database settings.
return [
    'host' => 'sql102.infinityfree.com',
    'user' => 'if0_43461690',
    'pass' => 'Johnmichael1308',
    'name' => 'if0_43461690_telecare_db',
];