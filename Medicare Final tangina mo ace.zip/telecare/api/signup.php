<?php
header('Content-Type: application/json; charset=utf-8');
include __DIR__ . '/../db_connect.php';

function fail($code, $msg) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

$in    = json_decode(file_get_contents('php://input'), true) ?: [];
$name  = trim($in['name'] ?? '');
$bid   = trim($in['barangay_id'] ?? '');
$email = strtolower(trim($in['email'] ?? ''));
$pass  = $in['password'] ?? '';

if ($bid === '' || mb_strlen($bid) > 30) {
    fail(400, 'Enter the Barangay ID number given by your barangay.');
}
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
    fail(400, 'Check your name, email and password (at least 6 characters).');
}

// 1. Is this a valid Barangay ID number (issued by the barangay)?
$stmt = $conn->prepare("SELECT barangay_id FROM barangay_registry WHERE barangay_id = ?");
$stmt->bind_param("s", $bid);
$stmt->execute();
$valid = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$valid) {
    fail(400, 'This Barangay ID number is not in the barangay list. Check the number or ask the barangay office.');
}
$bid = $valid['barangay_id'];   // use the exact value stored by the barangay

// 2. Does this Barangay ID already have an account?
$stmt = $conn->prepare("SELECT resident_id FROM resident WHERE barangay_id = ?");
$stmt->bind_param("s", $bid);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    fail(409, 'This Barangay ID number already has an account. Log in instead.');
}
$stmt->close();

// 3. Is the email already used?
$stmt = $conn->prepare("SELECT resident_id FROM resident WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    fail(409, 'An account with this email already exists. Log in instead.');
}
$stmt->close();

// 4. Create the account
$hash = password_hash($pass, PASSWORD_DEFAULT);
try {
    $stmt = $conn->prepare("INSERT INTO resident (barangay_id, full_name, email, password_hash) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $bid, $name, $email, $hash);
    $stmt->execute();
} catch (mysqli_sql_exception $e) {
    // 1062 = duplicate key (two people registering the same ID/email at the same moment)
    if ((int)$e->getCode() === 1062) {
        fail(409, 'This Barangay ID number or email already has an account. Log in instead.');
    }
    fail(500, 'Could not create the account. Please try again.');
}

echo json_encode(['ok' => true]);
$conn->close();
