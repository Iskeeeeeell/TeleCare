<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
include __DIR__ . '/../db_connect.php';

// ---- Limits (change these numbers if you want) ----
$maxFailsPerAccount = 5;    // wrong tries for the same Barangay ID / email
$maxFailsPerIp      = 20;   // wrong tries from the same device/network
$windowMinutes      = 1;    // how long the block lasts (in minutes)

function count_fails($conn, $col, $val, $minutes) {
    // $col is always a fixed word from this file ('ident' or 'ip'), never user input
    $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempt WHERE $col = ? AND attempted_at > (NOW() - INTERVAL ? MINUTE)");
    $stmt->bind_param('si', $val, $minutes);
    $stmt->execute();
    $stmt->bind_result($n);
    $stmt->fetch();
    $stmt->close();
    return (int)$n;
}

$in   = json_decode(file_get_contents('php://input'), true) ?: [];
$pass = $in['password'] ?? '';
$role = ($in['role'] ?? '') === 'admin' ? 'admin' : 'resident';
$ip   = $_SERVER['REMOTE_ADDR'] ?? '';

if ($role === 'admin') {
    // Administrator: email + password
    $ident = strtolower(trim($in['email'] ?? ''));
} else {
    // Resident: Barangay ID number (given by the barangay) + password
    $ident = trim($in['barangay_id'] ?? '');
}
$ident = mb_substr($ident, 0, 120);

if ($ident === '' || $pass === '') {
    http_response_code(401);
    echo json_encode(['ok' => false]);
    exit;
}

// Too many wrong tries? Stop here, before checking the password.
if (count_fails($conn, 'ident', $ident, $windowMinutes) >= $maxFailsPerAccount
    || count_fails($conn, 'ip', $ip, $windowMinutes) >= $maxFailsPerIp) {
    http_response_code(429);
    $waitText = $windowMinutes === 1 ? '1 minute' : "$windowMinutes minutes";
    echo json_encode(['ok' => false, 'error' => "Too many failed attempts. Please wait $waitText and try again."]);
    exit;
}

if ($role === 'admin') {
    $stmt = $conn->prepare("SELECT admin_id AS id, full_name, email, password_hash FROM admin WHERE email = ?");
} else {
    $stmt = $conn->prepare("SELECT resident_id AS id, full_name, email, password_hash FROM resident WHERE barangay_id = ?");
}
$stmt->bind_param("s", $ident);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if ($row && password_verify($pass, $row['password_hash'])) {
    // Correct login: clear this account's failed tries
    $clr = $conn->prepare("DELETE FROM login_attempt WHERE ident = ?");
    $clr->bind_param('s', $ident);
    $clr->execute();

    session_regenerate_id(true);
    $_SESSION['user'] = ['id' => $row['id'], 'role' => $role];
    echo json_encode(['ok' => true, 'user' => ['name' => $row['full_name'], 'email' => $row['email'], 'role' => $role]]);
} else {
    // Wrong login: record it (and tidy up records older than a day)
    $log = $conn->prepare("INSERT INTO login_attempt (ident, ip) VALUES (?, ?)");
    $log->bind_param('ss', $ident, $ip);
    $log->execute();
    $conn->query("DELETE FROM login_attempt WHERE attempted_at < (NOW() - INTERVAL 1 DAY)");

    http_response_code(401);
    echo json_encode(['ok' => false]);
}
$conn->close();