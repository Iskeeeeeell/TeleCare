<?php
// db_connect.php - Database connection for the TeleCare Clinic Information System.
// The settings (host, user, password, database name) are in config.php.
$config = require __DIR__ . '/config.php';

function db_unavailable() {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Cannot connect to the database right now.']);
    exit;
}

try {
    $conn = new mysqli($config['host'], $config['user'], $config['pass'], $config['name']);
    if ($conn->connect_error) {
        error_log('DB connection failed: ' . $conn->connect_error);
        db_unavailable();
    }
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    // Log the real reason privately; never show it to visitors.
    error_log('DB connection failed: ' . $e->getMessage());
    db_unavailable();
}

unset($config);