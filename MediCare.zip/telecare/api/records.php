<?php
// records.php - Resident medical records.
// Resident: nakikita LANG ang sarili niyang records (read-only).
// Admin: nakikita lahat, puwedeng mag-add / edit / delete.
session_start();
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Manila');
include __DIR__ . '/../db_connect.php';

function respond($data, $code = 200) { http_response_code($code); echo json_encode($data); exit; }

$user = $_SESSION['user'] ?? null;
if (!$user) respond(['ok' => false, 'error' => 'Please log in first.'], 401);

$isAdmin = $user['role'] === 'admin';
$userId  = (int)$user['id'];

$cols = "m.record_id AS id, m.resident_id, m.visit_date AS date, m.record_type AS type, m.complaint,
         m.blood_pressure AS bp, m.temperature AS temp, m.weight_kg AS weight, m.diagnosis, m.treatment,
         m.follow_up_date AS follow_up";
$types = ['Check-up', 'Consultation', 'Vaccination', 'Follow-up', 'Other'];

// ---- GET ----
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($isAdmin) {
        if (isset($_GET['residents'])) {   // listahan para sa dropdown ng admin
            respond($conn->query("SELECT resident_id AS id, full_name AS name, email FROM resident ORDER BY full_name")->fetch_all(MYSQLI_ASSOC));
        }
        $sql = "SELECT $cols, r.full_name AS resident
                FROM medical_record m LEFT JOIN resident r ON r.resident_id = m.resident_id
                ORDER BY m.visit_date DESC, m.record_id DESC";
        respond($conn->query($sql)->fetch_all(MYSQLI_ASSOC));
    }
    $stmt = $conn->prepare("SELECT $cols FROM medical_record m WHERE m.resident_id = ?
                            ORDER BY m.visit_date DESC, m.record_id DESC");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    respond($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
}

// ---- POST: admin lang ----
if (!$isAdmin) respond(['ok' => false, 'error' => 'Admin only'], 403);

$in     = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $in['action'] ?? '';
$id     = (int)($in['id'] ?? 0);

if ($action === 'delete') {
    $stmt = $conn->prepare("DELETE FROM medical_record WHERE record_id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    respond(['ok' => true]);
}

if ($action === 'save') {
    $residentId = (int)($in['resident_id'] ?? 0);
    $visit      = $in['date'] ?? '';
    $type       = $in['type'] ?? '';
    $complaint  = trim($in['complaint'] ?? '');
    $bp         = trim($in['bp'] ?? '');
    $temp       = trim((string)($in['temp'] ?? ''));
    $weight     = trim((string)($in['weight'] ?? ''));
    $diagnosis  = trim($in['diagnosis'] ?? '');
    $treatment  = trim($in['treatment'] ?? '');
    $followUp   = trim($in['follow_up'] ?? '');

    $validDate = function ($s) { $d = DateTime::createFromFormat('Y-m-d', $s); return $d && $d->format('Y-m-d') === $s; };

    $chk = $conn->prepare("SELECT 1 FROM resident WHERE resident_id = ?");
    $chk->bind_param('i', $residentId);
    $chk->execute();
    $chk->store_result();
    if ($chk->num_rows < 1)                 respond(['ok' => false, 'error' => 'Choose a resident.'], 400);
    $chk->close();

    if (!$validDate($visit))                respond(['ok' => false, 'error' => 'Choose a valid visit date.'], 400);
    if ($visit > date('Y-m-d'))             respond(['ok' => false, 'error' => 'The visit date cannot be in the future.'], 400);
    if (!in_array($type, $types, true))     respond(['ok' => false, 'error' => 'Choose a record type.'], 400);
    if ($complaint === '' || mb_strlen($complaint) > 255)  respond(['ok' => false, 'error' => 'Enter the complaint (up to 255 characters).'], 400);
    if (mb_strlen($diagnosis) > 255)        respond(['ok' => false, 'error' => 'Diagnosis is too long (up to 255 characters).'], 400);
    if (mb_strlen($treatment) > 2000)       respond(['ok' => false, 'error' => 'Treatment is too long (up to 2000 characters).'], 400);
    if ($bp !== '' && !preg_match('/^\d{2,3}\/\d{2,3}$/', $bp)) respond(['ok' => false, 'error' => 'Blood pressure should look like 120/80.'], 400);
    if ($temp !== '' && (!is_numeric($temp) || $temp < 30 || $temp > 45))   respond(['ok' => false, 'error' => 'Temperature must be between 30 and 45 °C.'], 400);
    if ($weight !== '' && (!is_numeric($weight) || $weight <= 0 || $weight > 500)) respond(['ok' => false, 'error' => 'Enter a valid weight in kg.'], 400);
    if ($followUp !== '' && !$validDate($followUp)) respond(['ok' => false, 'error' => 'Choose a valid follow-up date.'], 400);
    if ($followUp !== '' && $followUp < $visit)     respond(['ok' => false, 'error' => 'Follow-up cannot be before the visit date.'], 400);

    // Walang laman -> NULL
    $bp = $bp === '' ? null : $bp;
    $temp = $temp === '' ? null : $temp;
    $weight = $weight === '' ? null : $weight;
    $diagnosis = $diagnosis === '' ? null : $diagnosis;
    $treatment = $treatment === '' ? null : $treatment;
    $followUp = $followUp === '' ? null : $followUp;
    $adminId = (int)$user['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE medical_record SET resident_id=?, visit_date=?, record_type=?, complaint=?,
                                blood_pressure=?, temperature=?, weight_kg=?, diagnosis=?, treatment=?, follow_up_date=?
                                WHERE record_id=?");
        $stmt->bind_param('isssssssssi', $residentId, $visit, $type, $complaint, $bp, $temp, $weight, $diagnosis, $treatment, $followUp, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO medical_record (resident_id, visit_date, record_type, complaint, blood_pressure,
                                temperature, weight_kg, diagnosis, treatment, follow_up_date, recorded_by)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('isssssssssi', $residentId, $visit, $type, $complaint, $bp, $temp, $weight, $diagnosis, $treatment, $followUp, $adminId);
    }
    $stmt->execute();
    respond(['ok' => true]);
}

respond(['ok' => false, 'error' => 'Unknown action'], 400);
