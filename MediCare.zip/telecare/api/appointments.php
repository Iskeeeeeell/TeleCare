<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Manila');
include __DIR__ . '/../db_connect.php';

function respond($data, $code = 200) { http_response_code($code); echo json_encode($data); exit; }

$user = $_SESSION['user'] ?? null;
if (!$user) respond(['ok' => false, 'error' => 'Please log in first.'], 401);

$isAdmin    = $user['role'] === 'admin';
$residentId = (int)$user['id'];

// Same slots as js/appointments.js (APPT_SLOTS) - keep both lists in sync
$slots = [
  'Clinic' => ['8:00 AM','9:00 AM','10:00 AM','11:00 AM','1:00 PM','2:00 PM','3:00 PM','4:00 PM'],
  'Vet'    => ['9:00 AM','10:00 AM','11:00 AM','1:00 PM','2:00 PM','3:00 PM'],
];

// ---- GET: resident = sariling appointments, admin = lahat ----
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($isAdmin) {
        $sql = "SELECT a.appointment_id AS id, a.type, a.appt_date AS date, a.appt_time AS time, a.reason,
                       a.pet_name, a.pet_type, a.status, r.full_name AS resident
                FROM appointment a LEFT JOIN resident r ON r.resident_id = a.resident_id
                ORDER BY a.appt_date DESC, a.appointment_id DESC";
        respond($conn->query($sql)->fetch_all(MYSQLI_ASSOC));
    }
    $stmt = $conn->prepare("SELECT appointment_id AS id, type, appt_date AS date, appt_time AS time, reason,
                                   pet_name, pet_type, status
                            FROM appointment WHERE resident_id = ?
                            ORDER BY appt_date DESC, appointment_id DESC");
    $stmt->bind_param('i', $residentId);
    $stmt->execute();
    respond($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
}

$in     = json_decode(file_get_contents('php://input'), true) ?: [];
$action = $in['action'] ?? '';
$id     = (int)($in['id'] ?? 0);

// ---- POST: admin nagpapalit ng status ----
if ($action === 'status') {
    if (!$isAdmin) respond(['ok' => false, 'error' => 'Admin only'], 403);
    $status = $in['status'] ?? '';
    if (!in_array($status, ['Pending','Confirmed','Completed','Cancelled'], true)) {
        respond(['ok' => false, 'error' => 'Invalid status'], 400);
    }
    $stmt = $conn->prepare("UPDATE appointment SET status = ? WHERE appointment_id = ?");
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();
    respond(['ok' => true]);
}

// Ang create at cancel ay para sa residents lang
if ($isAdmin) respond(['ok' => false, 'error' => 'Residents only'], 403);

if ($action === 'create') {
    $type   = $in['type'] ?? '';
    $date   = $in['date'] ?? '';
    $time   = $in['time'] ?? '';
    $reason = trim($in['reason'] ?? '');
    $pet    = trim($in['pet_name'] ?? '');
    $petTyp = trim($in['pet_type'] ?? '');

    if (!isset($slots[$type]))                    respond(['ok' => false, 'error' => 'Choose Clinic or Vet.'], 400);
    if (!in_array($time, $slots[$type], true))    respond(['ok' => false, 'error' => 'Choose an available time.'], 400);
    $d = DateTime::createFromFormat('Y-m-d', $date);
    if (!$d || $d->format('Y-m-d') !== $date)     respond(['ok' => false, 'error' => 'Choose a valid date.'], 400);
    if ($date < date('Y-m-d'))                    respond(['ok' => false, 'error' => 'The date cannot be in the past.'], 400);
    if ($reason === '' || mb_strlen($reason) > 200) respond(['ok' => false, 'error' => 'Enter a short reason (up to 200 characters).'], 400);

    if ($type === 'Vet') {
        if ($pet === '' || $petTyp === '') respond(['ok' => false, 'error' => 'Enter your pet\'s name and type.'], 400);
        $pet = mb_substr($pet, 0, 80);
        $petTyp = mb_substr($petTyp, 0, 40);
    } else {
        $pet = null; $petTyp = null;
    }

    // Isang slot, isang appointment lang (hindi bibilangin ang Cancelled)
    $chk = $conn->prepare("SELECT COUNT(*) FROM appointment WHERE type=? AND appt_date=? AND appt_time=? AND status <> 'Cancelled'");
    $chk->bind_param('sss', $type, $date, $time);
    $chk->execute();
    $chk->bind_result($taken);
    $chk->fetch();
    $chk->close();
    if ($taken > 0) respond(['ok' => false, 'error' => 'That time is already taken. Please pick another.'], 409);

    $stmt = $conn->prepare("INSERT INTO appointment (resident_id, type, appt_date, appt_time, reason, pet_name, pet_type)
                            VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('issssss', $residentId, $type, $date, $time, $reason, $pet, $petTyp);
    $stmt->execute();
    respond(['ok' => true]);
}

if ($action === 'cancel') {
    $stmt = $conn->prepare("UPDATE appointment SET status='Cancelled'
                            WHERE appointment_id=? AND resident_id=? AND status IN ('Pending','Confirmed')");
    $stmt->bind_param('ii', $id, $residentId);
    $stmt->execute();
    if ($stmt->affected_rows < 1) respond(['ok' => false, 'error' => 'This appointment cannot be cancelled.'], 400);
    respond(['ok' => true]);
}

respond(['ok' => false, 'error' => 'Unknown action'], 400);
