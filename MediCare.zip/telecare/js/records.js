// records.js - Resident medical records.
// Resident page (#records): read-only list of their own records.
// Admin page (#admin#records): add / edit / delete records for any resident.
// Record types must match $types in api/records.php.
const REC_TYPES = ['Check-up', 'Consultation', 'Vaccination', 'Follow-up', 'Other'];

let recs = [], recsLoaded = false, recResidents = [], recQuery = '', recEditId = null;

function loadRecords() {
  recsLoaded = true;
  const s = session();
  const calls = [
    fetch('api/records.php', { credentials: 'same-origin' })
      .then(r => (r.ok ? r.json() : []))
      .then(d => { recs = Array.isArray(d) ? d : []; })
      .catch(() => { recs = []; })
  ];
  if (s && s.role === 'admin') {
    calls.push(
      fetch('api/records.php?residents=1', { credentials: 'same-origin' })
        .then(r => (r.ok ? r.json() : []))
        .then(d => { recResidents = Array.isArray(d) ? d : []; })
        .catch(() => { recResidents = []; })
    );
  }
  return Promise.all(calls).then(route);
}

const recPost = body => fetch('api/records.php', {
  method: 'POST',
  credentials: 'same-origin',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(body)
}).then(r => r.json());

/* ===== RESIDENT PAGE ===== */

function residentTabs(active) {
  return `<div class="row rec-tabs">
    <a class="btn sm ${active === 'appointment' ? 'pri' : ''}" href="#appointment">Appointments</a>
    <a class="btn sm ${active === 'records' ? 'pri' : ''}" href="#records">Medical records</a>
  </div>`;
}

function records() {
  const s = session();
  if (!s || s.role !== 'resident') {
    location.hash = s ? '#admin#records' : '#login';
    role = 'resident';
    return '';
  }

  const list = recs.length
    ? recs.map(residentRecordCard).join('')
    : '<div class="card"><p class="muted">No medical records yet. Records added by the clinic after your visits will show up here.</p></div>';

  return header('records') + `
    <section class="appt">
      <div class="wrap">
        ${residentTabs('records')}
        <span class="eyebrow">My health</span>
        <h1 style="font-size:44px;margin:8px 0">My medical records</h1>
        <p class="muted" style="max-width:560px">A history of your visits, recorded by clinic staff. You can view them here but only the clinic can change them.</p>
        <div style="margin-top:28px">${list}</div>
        <div class="note">Private information. Log out when using a shared device. For corrections, please talk to the clinic.</div>
      </div>
    </section>` + footer();
}

function recVitals(r) {
  const v = [];
  if (r.bp) v.push('BP ' + esc(r.bp));
  if (r.temp !== null && r.temp !== '') v.push(esc(r.temp) + ' °C');
  if (r.weight !== null && r.weight !== '') v.push(esc(r.weight) + ' kg');
  return v.length ? `<small>${v.join(' · ')}</small>` : '';
}

function residentRecordCard(r) {
  return `
    <div class="card rec-card">
      <div class="rec-head">
        <b>${esc(fmt(r.date))}</b>
        <span class="pill ok">${esc(r.type)}</span>
      </div>
      <dl class="rec-dl">
        <dt>Complaint</dt><dd>${esc(r.complaint)}</dd>
        ${r.diagnosis ? `<dt>Diagnosis</dt><dd>${esc(r.diagnosis)}</dd>` : ''}
        ${r.treatment ? `<dt>Treatment / medication</dt><dd>${esc(r.treatment).replace(/\n/g, '<br>')}</dd>` : ''}
        ${r.follow_up ? `<dt>Follow-up</dt><dd>${esc(fmt(r.follow_up))}</dd>` : ''}
      </dl>
      ${recVitals(r)}
    </div>`;
}

/* ===== ADMIN PAGE ===== */

function filteredRecords() {
  const q = recQuery.trim().toLowerCase();
  if (!q) return recs;
  return recs.filter(r =>
    [r.resident, r.complaint, r.diagnosis, r.type].some(v => (v || '').toLowerCase().includes(q)));
}

function adminRecordRows() {
  const rows = filteredRecords();
  if (!rows.length) {
    return `<tr><td colspan="5" class="muted">${recs.length ? 'No records match your search.' : 'No medical records yet.'}</td></tr>`;
  }
  return rows.map(r => `
    <tr>
      <td><b>${esc(fmt(r.date))}</b><small>${esc(r.type)}</small></td>
      <td>${esc(r.resident || 'Unknown')}</td>
      <td>${esc(r.complaint)}${recVitals(r)}</td>
      <td>${esc(r.diagnosis || '—')}</td>
      <td style="white-space:nowrap">
        <button class="btn sm" data-rec-edit="${r.id}">Edit</button>
        <button class="btn sm red" data-rec-del="${r.id}">Delete</button>
      </td>
    </tr>`).join('');
}

function adminRecords() {
  const s = session();
  if (!s || s.role !== 'admin') {
    location.hash = '#login';
    role = 'admin';
    return '';
  }

  return `
    <div class="adm">
      ${adminSidebar('records')}
      <main class="main-a">
        <div class="crumb">
          <span>Clinic workspace / Medical records</span>
          <b>${esc(s.name)}</b>
        </div>
        <div class="pad">
          <span class="eyebrow">Medical records</span>
          <h1 style="font-size:40px;margin:8px 0">Resident medical records</h1>
          <p class="muted" style="margin-bottom:20px">Confidential. Residents can only view their own records.</p>
          <div class="row" style="margin-bottom:20px;gap:12px;flex-wrap:wrap">
            <input id="rq" type="search" placeholder="Search resident, complaint or diagnosis" value="${esc(recQuery)}" style="flex:1;min-width:220px;margin:0">
            <button class="btn pri" data-rec-new>+ New record</button>
          </div>
          <div class="card" style="padding:0;overflow:auto">
            <table>
              <thead><tr><th>Visit</th><th>Resident</th><th>Complaint</th><th>Diagnosis</th><th></th></tr></thead>
              <tbody id="recRows">${adminRecordRows()}</tbody>
            </table>
          </div>
        </div>
      </main>
    </div>`;
}

function openRecordDialog(id) {
  recEditId = id || null;
  const r = id ? recs.find(x => x.id == id) : null;
  let dialog = document.getElementById('recDialog');
  if (dialog) dialog.remove();

  dialog = document.createElement('dialog');
  dialog.id = 'recDialog';
  const val = k => esc(r && r[k] !== null && r[k] !== undefined ? r[k] : '');
  dialog.innerHTML = `
    <form id="rf" novalidate>
      <h3>${r ? 'Edit record' : 'New medical record'}</h3>
      <label for="rres">Resident</label>
      <select id="rres" ${r ? 'disabled' : ''}>
        <option value="">Select a resident</option>
        ${recResidents.map(x => `<option value="${x.id}" ${r && r.resident_id == x.id ? 'selected' : ''}>${esc(x.name)} (${esc(x.email)})</option>`).join('')}
      </select>
      <div class="rec-two">
        <div><label for="rdate">Visit date</label><input id="rdate" type="date" max="${localISO()}" value="${val('date')}"></div>
        <div><label for="rtype">Type</label><select id="rtype">${REC_TYPES.map(t => `<option ${r && r.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
      </div>
      <label for="rcomp">Complaint</label>
      <input id="rcomp" maxlength="255" value="${val('complaint')}">
      <div class="rec-three">
        <div><label for="rbp">Blood pressure</label><input id="rbp" placeholder="120/80" maxlength="7" value="${val('bp')}"></div>
        <div><label for="rtemp">Temp (°C)</label><input id="rtemp" type="number" step="0.1" min="30" max="45" value="${val('temp')}"></div>
        <div><label for="rwt">Weight (kg)</label><input id="rwt" type="number" step="0.1" min="1" max="500" value="${val('weight')}"></div>
      </div>
      <label for="rdx">Diagnosis</label>
      <input id="rdx" maxlength="255" value="${val('diagnosis')}">
      <label for="rtx">Treatment / medication</label>
      <textarea id="rtx" rows="3" maxlength="2000">${val('treatment')}</textarea>
      <label for="rfu">Follow-up date (optional)</label>
      <input id="rfu" type="date" value="${val('follow_up')}">
      <div class="err" id="rerr" role="alert"></div>
      <div class="row" style="margin-top:12px;justify-content:flex-end">
        <button type="button" class="btn" data-rec-close>Cancel</button>
        <button class="btn pri">Save record</button>
      </div>
    </form>`;
  document.body.appendChild(dialog);
  dialog.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });
  dialog.showModal();
}

function submitRecord() {
  const err = m => { $('#rerr').textContent = m; };
  const existing = recEditId ? recs.find(x => x.id == recEditId) : null;
  const body = {
    action: 'save',
    id: recEditId || 0,
    resident_id: existing ? Number(existing.resident_id) : Number($('#rres').value),
    date: $('#rdate').value,
    type: $('#rtype').value,
    complaint: $('#rcomp').value.trim(),
    bp: $('#rbp').value.trim(),
    temp: $('#rtemp').value,
    weight: $('#rwt').value,
    diagnosis: $('#rdx').value.trim(),
    treatment: $('#rtx').value.trim(),
    follow_up: $('#rfu').value
  };

  if (!body.resident_id) return err('Choose a resident.');
  if (!body.date) return err('Choose the visit date.');
  if (body.date > localISO()) return err('The visit date cannot be in the future.');
  if (!body.complaint) return err('Enter the complaint.');
  if (body.bp && !/^\d{2,3}\/\d{2,3}$/.test(body.bp)) return err('Blood pressure should look like 120/80.');
  if (body.follow_up && body.follow_up < body.date) return err('Follow-up cannot be before the visit date.');
  err('');

  recPost(body)
    .then(res => {
      if (!res.ok) return err(res.error || 'Could not save the record.');
      document.getElementById('recDialog')?.close();
      toast(recEditId ? 'Record updated' : 'Record saved');
      return loadRecords();
    })
    .catch(() => err('Cannot reach the server.'));
}

function deleteRecord(id) {
  if (!confirm('Delete this medical record? This cannot be undone.')) return;
  recPost({ action: 'delete', id: Number(id) })
    .then(res => {
      toast(res.ok ? 'Record deleted' : (res.error || 'Could not delete.'));
      return loadRecords();
    })
    .catch(() => toast('Cannot reach the server.'));
}

/* ===== EVENTS (self-contained, so app.js stays small) ===== */

document.addEventListener('click', e => {
  const t = e.target.closest('[data-rec-new],[data-rec-edit],[data-rec-del],[data-rec-close]');
  if (!t) return;
  if (t.hasAttribute('data-rec-new')) return openRecordDialog();
  if (t.hasAttribute('data-rec-edit')) return openRecordDialog(t.dataset.recEdit);
  if (t.hasAttribute('data-rec-del')) return deleteRecord(t.dataset.recDel);
  if (t.hasAttribute('data-rec-close')) return document.getElementById('recDialog')?.close();
});

document.addEventListener('submit', e => {
  if (e.target.id !== 'rf') return;
  e.preventDefault();
  submitRecord();
});

// Search only redraws the table rows, so the cursor stays in the box
document.addEventListener('input', e => {
  if (e.target.id !== 'rq') return;
  recQuery = e.target.value;
  const body = document.getElementById('recRows');
  if (body) body.innerHTML = adminRecordRows();
});
