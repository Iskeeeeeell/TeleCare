// appointments.js - Resident appointment booking (Clinic + Vet) and the admin appointment list.
// Time slots below must match $slots in api/appointments.php.
const APPT_SLOTS = {
  Clinic: ['8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'],
  Vet:    ['9:00 AM', '10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM', '3:00 PM'],
};
const APPT_INFO = {
  Clinic: 'Check-ups and consultations for residents',
  Vet:    'Pet check-ups and vaccinations',
};
const APPT_STATUSES = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];

let appts = [], apptsLoaded = false, apptType = 'Clinic';

// Local (Philippine) date as YYYY-MM-DD, used for the date picker minimum
const localISO = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

function loadAppointments() {
  apptsLoaded = true;
  return fetch('api/appointments.php', { credentials: 'same-origin' })
    .then(r => (r.ok ? r.json() : []))
    .then(d => { appts = Array.isArray(d) ? d : []; })
    .catch(() => { appts = []; })
    .then(route);
}

const slotOptions = type =>
  '<option value="">Select a time</option>' +
  APPT_SLOTS[type].map(t => `<option>${t}</option>`).join('');

/* ===== RESIDENT PAGE ===== */

function appointment() {
  const s = session();
  if (!s || s.role !== 'resident') {
    location.hash = s ? '#admin' : '#login';
    role = 'resident';
    return '';
  }

  const typeButtons = ['Clinic', 'Vet'].map(t => `
    <button type="button" class="apt-type ${apptType === t ? 'on' : ''}" data-apt="${t}">
      <b>${t}</b><span>${APPT_INFO[t]}</span>
    </button>`).join('');

  return header('appointment') + `
    <section class="appt">
      <div class="wrap">
        ${residentTabs('appointment')}
        <span class="eyebrow">Resident appointments</span>
        <h1 style="font-size:44px;margin:8px 0">Book an appointment</h1>
        <p class="muted" style="max-width:560px">Pick Clinic or Vet, then choose a date and time. The clinic will confirm your request.</p>

        <div class="appt-grid">
          <div class="card">
            <h3>New appointment</h3>
            <label>Where do you want to go?</label>
            <div class="apt-types">${typeButtons}</div>

            <form id="af" novalidate>
              <label for="ad">Date</label>
              <input id="ad" type="date" min="${localISO()}">

              <label for="at">Time</label>
              <select id="at">${slotOptions(apptType)}</select>

              <div id="vetFields" ${apptType === 'Vet' ? '' : 'hidden'}>
                <label for="apn">Pet's name</label>
                <input id="apn" maxlength="80" placeholder="e.g. Bantay">
                <label for="apt">Type of pet</label>
                <select id="apt">
                  <option value="">Select</option>
                  <option>Dog</option><option>Cat</option><option>Other</option>
                </select>
              </div>

              <label for="ar">Reason for visit</label>
              <textarea id="ar" rows="3" maxlength="200" placeholder="Short reason, e.g. check-up, anti-rabies vaccine"></textarea>

              <button class="btn pri" style="width:100%;justify-content:center;padding:16px;margin-top:18px">Request appointment →</button>
              <div class="err" id="aerr" role="alert"></div>
            </form>
            <div class="note">Keep it short. Do not write medical histories or private details here.</div>
          </div>

          <div>
            <h3 style="font-size:24px;margin-bottom:14px">My appointments</h3>
            ${appointmentList()}
          </div>
        </div>
      </div>
    </section>` + footer();
}

function appointmentList() {
  if (!appts.length) {
    return '<div class="card"><p class="muted">No appointments yet. Your requests will show up here.</p></div>';
  }

  return appts.map(a => {
    const canCancel = ['Pending', 'Confirmed'].includes(a.status) && a.date >= localISO();
    const pet = a.type === 'Vet' && a.pet_name
      ? `<small>Pet: ${esc(a.pet_name)}${a.pet_type ? ' (' + esc(a.pet_type) + ')' : ''}</small>` : '';

    return `
      <div class="card appt-row">
        <div>
          <span class="pill ${a.type === 'Vet' ? '' : 'ok'}">${esc(a.type)}</span>
          <b style="display:block;margin-top:8px">${esc(fmt(a.date))} · ${esc(a.time)}</b>
          <p>${esc(a.reason)}</p>
          ${pet}
        </div>
        <div class="appt-side">
          <span class="pill ${a.status === 'Confirmed' || a.status === 'Completed' ? 'ok' : ''}">${esc(a.status)}</span>
          ${canCancel ? `<button class="btn sm red" data-apt-cancel="${a.id}">Cancel</button>` : ''}
        </div>
      </div>`;
  }).join('');
}

// Switch Clinic / Vet without redrawing the page, so typed text is not lost
function setApptType(type) {
  apptType = type;

  document.querySelectorAll('.apt-type').forEach(b =>
    b.classList.toggle('on', b.dataset.apt === type));

  const vet = $('#vetFields');
  if (vet) vet.hidden = type !== 'Vet';

  const time = $('#at');
  if (time) time.innerHTML = slotOptions(type);
}

function submitAppointment() {
  const err = m => { $('#aerr').textContent = m; };

  const body = {
    action: 'create',
    type: apptType,
    date: $('#ad').value,
    time: $('#at').value,
    reason: $('#ar').value.trim(),
    pet_name: $('#apn')?.value.trim() || '',
    pet_type: $('#apt')?.value || ''
  };

  if (!body.date) return err('Choose a date.');
  if (body.date < localISO()) return err('The date cannot be in the past.');
  if (!body.time) return err('Choose a time.');
  if (apptType === 'Vet' && (!body.pet_name || !body.pet_type)) return err('Enter your pet\'s name and type.');
  if (!body.reason) return err('Enter a short reason for the visit.');

  err('');

  fetch('api/appointments.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  })
    .then(r => r.json())
    .then(res => {
      if (!res.ok) return err(res.error || 'Could not save your appointment.');
      toast('Appointment requested. Waiting for confirmation.');
      return loadAppointments();
    })
    .catch(() => err('Cannot reach the server. Is Apache running?'));
}

function cancelAppointment(id) {
  if (!confirm('Cancel this appointment?')) return;

  fetch('api/appointments.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'cancel', id: Number(id) })
  })
    .then(r => r.json())
    .then(res => {
      toast(res.ok ? 'Appointment cancelled' : (res.error || 'Could not cancel.'));
      return loadAppointments();
    })
    .catch(() => toast('Cannot reach the server.'));
}

/* ===== ADMIN PAGE ===== */

function adminAppointments() {
  const s = session();
  if (!s || s.role !== 'admin') {
    location.hash = '#login';
    role = 'admin';
    return '';
  }

  const rows = appts.length ? appts.map(a => `
    <tr>
      <td><b>${esc(fmt(a.date))}</b><small>${esc(a.time)}</small></td>
      <td><span class="pill ${a.type === 'Vet' ? '' : 'ok'}">${esc(a.type)}</span></td>
      <td>${esc(a.resident || 'Unknown')}
        ${a.type === 'Vet' && a.pet_name ? `<small>Pet: ${esc(a.pet_name)}${a.pet_type ? ' (' + esc(a.pet_type) + ')' : ''}</small>` : ''}
      </td>
      <td>${esc(a.reason)}</td>
      <td>
        <select data-apt-status="${a.id}" aria-label="Status" style="padding:8px">
          ${APPT_STATUSES.map(st => `<option ${st === a.status ? 'selected' : ''}>${st}</option>`).join('')}
        </select>
      </td>
    </tr>`).join('')
    : '<tr><td colspan="5" class="muted">No appointments yet.</td></tr>';

  return `
    <div class="adm">
      ${adminSidebar('appointments')}
      <main class="main-a">
        <div class="crumb">
          <span>Clinic workspace / Appointments</span>
          <b>${esc(s.name)}</b>
        </div>
        <div class="pad">
          <span class="eyebrow">Appointments</span>
          <h1 style="font-size:40px;margin:8px 0">Resident appointments</h1>
          <p class="muted" style="margin-bottom:24px">Clinic and Vet requests. Change the status to confirm, complete or cancel.</p>
          <div class="card" style="padding:0;overflow:auto">
            <table>
              <thead><tr><th>Date &amp; time</th><th>Type</th><th>Resident</th><th>Reason</th><th>Status</th></tr></thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
        </div>
      </main>
    </div>`;
}

function setAppointmentStatus(id, status) {
  fetch('api/appointments.php', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'status', id: Number(id), status })
  })
    .then(r => r.json())
    .then(res => {
      toast(res.ok ? 'Status updated' : (res.error || 'Could not update.'));
      return loadAppointments();
    })
    .catch(() => toast('Cannot reach the server.'));
}
