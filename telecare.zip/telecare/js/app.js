// app.js - Router and click/form handlers

const pages = { home, about, login, admin };

function route() {
  const [pageName, sectionId] = location.hash.replace(/^#/, '').split('#');
  const page = pages[pageName] ? pageName : 'home';

  app.innerHTML =
    page === 'admin' && sectionId &&
    ['services', 'team', 'hours', 'contact'].includes(sectionId)
      ? adminSection(sectionId)
      : pages[page]();

  document.title = 'TeleCare · ' + page[0].toUpperCase() + page.slice(1);

  const section = sectionId && document.getElementById(sectionId);
  if (section) section.scrollIntoView();
  else window.scrollTo(0, 0);
}

addEventListener('hashchange', route);

const todayISO = () => new Date().toISOString().slice(0, 10);

function showLoginError(message) {
  $('#err').textContent = message;
}

document.addEventListener('click', e => {
  const target = e.target.closest(
    '[data-act],[data-role],[data-f],[data-tg],[data-ed],[data-del]'
  );

  if (!target) return;

  const d = target.dataset;

  if (d.role) return chooseRole(d.role);
  if (d.f) return setFilter(d.f);
  if (d.tg) return toggleNotice(d.tg);
  if (d.del) return deleteNotice(d.del);
  if (d.ed) return openEditNotice(d.ed);

  switch (d.act) {
    case 'new':
      return openNewNotice();

    case 'logout':
      return confirmLogout();

    case 'logout-cancel':
      return closeLogoutDialog();

    case 'logout-confirm':
      return closeLogoutDialog(true);

    case 'eye':
      return togglePassword(target);

    case 'mode':
      e.preventDefault();
      return toggleSignupMode();

    case 'forgot':
      e.preventDefault();
      return toast('Password reset is not part of this demo.');

    case 'soon':
      return toast('This section is not built in the demo yet.');

    case 'menu': {
      const bar = target.closest('header.top');
      const open = bar.classList.toggle('open');
      target.setAttribute('aria-expanded', open);
      target.textContent = open ? '✕' : '☰';
      return;
    }

    case 'goann': {
      e.preventDefault();

      document.querySelectorAll('.side a')
        .forEach(link => link.classList.remove('on'));

      const announcementsLink =
        document.querySelector('.side a[data-act="goann"]');

      if (announcementsLink) announcementsLink.classList.add('on');

      const announcementsSection = $('#ann');

      if (announcementsSection) {
        announcementsSection.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }

      return;
    }
  }
});

document.addEventListener('click', e => {
  if (e.target.closest('nav.main a')) {
    $('header.top')?.classList.remove('open');
  }
});

// Login page

function chooseRole(newRole) {
  role = newRole;
  mode = 'login';
  route();
}

function toggleSignupMode() {
  mode = mode === 'login' ? 'signup' : 'login';
  route();
}

function togglePassword(button) {
  const input = $('#pw');

  input.type = input.type === 'password' ? 'text' : 'password';

  button.textContent = input.type === 'password' ? 'Show' : 'Hide';
}

// Logout confirmation modal

function confirmLogout() {
  let dialog = document.getElementById('logoutConfirmDialog');

  if (!dialog) {
    dialog = document.createElement('dialog');
    dialog.id = 'logoutConfirmDialog';

    dialog.innerHTML = `
      <div class="logout-confirm">
        <div class="logout-icon" aria-hidden="true">↪</div>
        <h2>Log out of TeleCare?</h2>
        <p>
          Are you sure you want to log out?
          You can sign in again anytime.
        </p>
        <div class="row logout-actions">
          <button class="btn" data-act="logout-cancel">Cancel</button>
          <button class="btn pri" data-act="logout-confirm">
            Yes, log out
          </button>
        </div>
      </div>`;

    document.body.appendChild(dialog);

    dialog.addEventListener('click', event => {
      if (event.target === dialog) closeLogoutDialog();
    });

    dialog.addEventListener('cancel', event => {
      event.preventDefault();
      closeLogoutDialog();
    });
  }

  dialog.showModal();
}

function closeLogoutDialog(shouldLogout = false) {
  document.getElementById('logoutConfirmDialog')?.close();

  if (shouldLogout) logout();
}

function logout() {
  fetch('api/logout.php').finally(() => {
    clearSession();
    location.hash = '#home';
    loadNotices();
    toast('Logged out');
  });
}

// Load clinic content from MySQL

async function syncSiteContentFromDatabase() {
  try {
    const response = await fetch('api/site_content.php', {
      credentials: 'same-origin'
    });

    const result = await response.json();

    if (result.ok && result.content) {
      localStorage.setItem(
        'tc_site_content',
        JSON.stringify(result.content)
      );
    }
  } catch (error) {
    console.warn(
      'Could not load clinic content from database.',
      error
    );
  }
}

// Admin content editor saving

document.addEventListener('submit', async e => {
  const form = e.target.closest('#contentEditor');

  if (!form) return;

  e.preventDefault();

  const saved = load('tc_site_content', {});
  const section = form.dataset.section;

  const key = section === 'team' ? 'teamCategories' : section;
  const base = siteContent();

  const value = section === 'contact'
    ? { ...base.contact }
    : [...base[key]];

  form.querySelectorAll('[data-content-key]').forEach(input => {
    const idx = input.dataset.index;
    const prop = input.dataset.prop;

    if (section === 'contact') {
      value[prop] = input.value.trim();
    } else {
      value[Number(idx)][prop] = input.value.trim();
    }
  });

  try {
    const response = await fetch('api/site_content.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ section, value })
    });

    const result = await response.json();

    if (!result.ok) {
      return toast(result.error || 'Could not save changes.');
    }

    saved[key] = value;

    localStorage.setItem(
      'tc_site_content',
      JSON.stringify(saved)
    );

    toast('Changes saved to database');

    await syncSiteContentFromDatabase();
    route();

  } catch (error) {
    toast('Cannot reach the server.');
  }
});
// Admin dashboard: notices

function setFilter(status) {
  filt = status;
  route();
}

function sendNotice(data, message) {
  return fetch('api/notices.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
    .then(r => r.json())
    .then(res => {
      if (!res.ok) {
        return toast(res.error || 'Could not save. Please log in again.');
      }

      toast(message);
      return loadNotices();
    })
    .catch(() => toast('Cannot reach the server.'));
}

function toggleNotice(id) {
  sendNotice({ action: 'toggle', id }, 'Status updated');
}

function deleteNotice(id) {
  if (!confirm('Delete this notice? This cannot be undone.')) return;

  sendNotice({ action: 'delete', id }, 'Deleted');
}

function openNewNotice() {
  editId = null;
  $('#nf').reset();
  $('#dt').textContent = 'New notice';
  dlg.showModal();
}

function openEditNotice(id) {
  const notice = notices.find(n => n.id == id);

  editId = notice.id;
  $('#dt').textContent = 'Edit notice';
  $('#nt').value = notice.title;
  $('#nc').value = notice.cat;
  $('#ns').value = notice.status;
  $('#nb').value = notice.body;

  dlg.showModal();
}

// Search box

document.addEventListener('input', e => {
  if (e.target.id !== 'sq') return;

  q = e.target.value;

  const cursor = e.target.selectionStart;
  route();

  const box = $('#sq');

  if (box) {
    box.focus();

    const position = Math.min(cursor, box.value.length);
    box.setSelectionRange(position, position);
  }
});

// Checklist

document.addEventListener('change', e => {
  if (e.target.dataset.ck === undefined) return;

  const ticked = load('tc_ck', []);
  ticked[e.target.dataset.ck] = e.target.checked;

  save('tc_ck', ticked);
});

// Forms

document.addEventListener('submit', e => {
  if (e.target.id === 'lf') {
    e.preventDefault();

    return mode === 'signup'
      ? createResidentAccount()
      : logIn();
  }

  if (e.target.id === 'nf') return saveNotice();
});

function createResidentAccount() {
  const name = $('#nm').value.trim();
  const email = $('#em').value.trim().toLowerCase();
  const password = $('#pw').value;

  if (!email || !password) {
    return showLoginError('Enter your email address and password.');
  }

  if (!name) {
    return showLoginError('Enter your full name.');
  }

  if (password.length < 6) {
    return showLoginError('Use a password with at least 6 characters.');
  }

  fetch('api/signup.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password })
  })
    .then(r => r.json())
    .then(res => {
      if (!res.ok) {
        return showLoginError(res.error || 'Could not create the account.');
      }

      mode = 'login';
      route();

      toast('Account created. You can log in now.');
    })
    .catch(() => {
      showLoginError('Cannot reach the server. Is Apache running?');
    });
}

function logIn() {
  const email = $('#em').value.trim().toLowerCase();
  const password = $('#pw').value;

  if (!email || !password) {
    return showLoginError('Enter your email address and password.');
  }

  fetch('api/login.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, role })
  })
    .then(r => r.json())
    .then(res => {
      if (!res.ok) {
        return showLoginError(
          'Email or password is incorrect. Check them and try again.'
        );
      }

      saveSession(res.user, $('#rm').checked);
      loadNotices();

      location.hash = res.user.role === 'admin' ? '#admin' : '#home';

      toast('Welcome, ' + res.user.name.split(' ')[0]);
    })
    .catch(() => {
      showLoginError('Cannot reach the server. Is Apache running?');
    });
}

function saveNotice() {
  sendNotice({
    action: 'save',
    id: editId || 0,
    title: $('#nt').value.trim(),
    cat: $('#nc').value,
    status: $('#ns').value,
    body: $('#nb').value.trim()
  }, editId ? 'Changes saved' : 'Notice saved');
}

// Draw the first page when the site opens

syncSiteContentFromDatabase().finally(route);