<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
include __DIR__ . '/../db_connect.php';

$types = [
  'services' => ['table' => 'clinic_service',     'id' => 'service_id', 'cols' => ['title', 'description']],
  'team'     => ['table' => 'healthcare_team',    'id' => 'team_id',    'cols' => ['title', 'description']],
  'hours'    => ['table' => 'operating_hour',     'id' => 'hour_id',    'cols' => ['days', 'hours', 'status']],
  'contact'  => ['table' => 'clinic_information', 'id' => 'clinic_id',  'cols' => ['clinic_name', 'address', 'phone', 'email']],
];

// GET: pampubliko, ibinabalik ang apat na grupo
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $out = [];
    foreach ($types as $key => $t) {
        $sql = "SELECT {$t['id']} AS id, " . implode(', ', $t['cols']) . " FROM {$t['table']} ORDER BY {$t['id']}";
        $out[$key] = $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
    }
    echo json_encode($out);
    exit;
}

// POST: admin lang
if (($_SESSION['user']['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Admin only']);
    exit;
}

$in     = json_decode(file_get_contents('php://input'), true);
$type   = $in['type'] ?? '';
$action = $in['action'] ?? '';
$id     = (int)($in['id'] ?? 0);

if (!isset($types[$type])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Unknown type']);
    exit;
}
$t = $types[$type];

if ($action === 'save') {
    $vals = [];
    foreach ($t['cols'] as $c) $vals[] = trim($in['data'][$c] ?? '');

    if ($vals[0] === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'The first field is required']);
        exit;
    }

    $bind = str_repeat('s', count($vals));
    if ($id) {
        $set  = implode(', ', array_map(fn($c) => "$c = ?", $t['cols']));
        $stmt = $conn->prepare("UPDATE {$t['table']} SET $set WHERE {$t['id']} = ?");
        $bind .= 'i';
        $vals[] = $id;
    } else {
        $ph   = implode(', ', array_fill(0, count($vals), '?'));
        $stmt = $conn->prepare("INSERT INTO {$t['table']} (" . implode(', ', $t['cols']) . ") VALUES ($ph)");
    }
    $stmt->bind_param($bind, ...$vals);
    $stmt->execute();

} elseif ($action === 'delete' && $type !== 'contact') {
    $stmt = $conn->prepare("DELETE FROM {$t['table']} WHERE {$t['id']} = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();

} else {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Unknown action']);
    exit;
}

echo json_encode(['ok' => true]);
$conn->close();