<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../db_connect.php';

function respond($data, $code = 200) { http_response_code($code); echo json_encode($data); exit; }
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'POST' && (($_SESSION['user']['role'] ?? '') !== 'admin')) respond(['ok'=>false,'error'=>'Administrator login required.'], 403);

if ($method === 'GET') {
  $services=[]; $res=$conn->query('SELECT title, description FROM clinic_service ORDER BY service_id');
  if ($res) while($r=$res->fetch_assoc()) $services[]=['title'=>$r['title'],'text'=>$r['description'] ?? ''];
  $team=[]; $res=$conn->query('SELECT title, description FROM healthcare_team ORDER BY team_id');
  if ($res) while($r=$res->fetch_assoc()) $team[]=['title'=>$r['title'],'text'=>$r['description'] ?? ''];
  $hours=[]; $res=$conn->query('SELECT days, hours, status FROM operating_hour ORDER BY hour_id');
  if ($res) while($r=$res->fetch_assoc()) $hours[]=['days'=>$r['days'],'time'=>$r['hours'] ?? '', 'status'=>$r['status'] ?? ''];
  $contact=['name'=>'','address'=>'','phone'=>'','email'=>'','about'=>''];
  $res=$conn->query('SELECT clinic_name,address,phone,email,about_description FROM clinic_information ORDER BY clinic_id LIMIT 1');
  if ($res && $r=$res->fetch_assoc()) $contact=['name'=>$r['clinic_name'] ?? '', 'address'=>$r['address'] ?? '', 'phone'=>$r['phone'] ?? '', 'email'=>$r['email'] ?? '', 'about'=>$r['about_description'] ?? ''];
  respond(['ok'=>true,'content'=>['services'=>$services,'teamCategories'=>$team,'hours'=>$hours,'contact'=>$contact]]);
}
if ($method !== 'POST') respond(['ok'=>false,'error'=>'Method not allowed'],405);
$in=json_decode(file_get_contents('php://input'),true); $section=$in['section'] ?? ''; $value=$in['value'] ?? null;
$conn->begin_transaction();
try {
  if ($section==='services' || $section==='team') {
    if (!is_array($value)) throw new Exception('Invalid content format.');
    $table=$section==='services'?'clinic_service':'healthcare_team';
    $conn->query("DELETE FROM `$table`");
    $stmt=$conn->prepare("INSERT INTO `$table` (title,description) VALUES (?,?)");
    foreach($value as $item){$title=trim((string)($item['title']??''));$desc=trim((string)($item['text']??'')); if($title==='') continue; $stmt->bind_param('ss',$title,$desc);$stmt->execute();}
  } elseif ($section==='hours') {
    if (!is_array($value)) throw new Exception('Invalid schedule format.');
    $conn->query('DELETE FROM operating_hour'); $stmt=$conn->prepare('INSERT INTO operating_hour (days,hours,status) VALUES (?,?,?)');
    foreach($value as $item){$days=trim((string)($item['days']??''));$time=trim((string)($item['time']??''));$status=trim((string)($item['status']??''));if($days==='')continue;$stmt->bind_param('sss',$days,$time,$status);$stmt->execute();}
  } elseif ($section==='contact') {
    if (!is_array($value)) throw new Exception('Invalid clinic information.');
    $name=trim((string)($value['name']??''));$address=trim((string)($value['address']??''));$phone=trim((string)($value['phone']??''));$email=trim((string)($value['email']??''));$about=trim((string)($value['about']??''));
    $res=$conn->query('SELECT clinic_id FROM clinic_information ORDER BY clinic_id LIMIT 1');
    if($res && $r=$res->fetch_assoc()){$id=(int)$r['clinic_id'];$stmt=$conn->prepare('UPDATE clinic_information SET clinic_name=?,address=?,phone=?,email=?,about_description=? WHERE clinic_id=?');$stmt->bind_param('sssssi',$name,$address,$phone,$email,$about,$id);$stmt->execute();}
    else {$stmt=$conn->prepare('INSERT INTO clinic_information (clinic_name,address,phone,email,about_description) VALUES (?,?,?,?,?)');$stmt->bind_param('sssss',$name,$address,$phone,$email,$about);$stmt->execute();}
  } else throw new Exception('Unknown section.');
  $conn->commit(); respond(['ok'=>true]);
} catch(Throwable $e) { $conn->rollback(); respond(['ok'=>false,'error'=>$e->getMessage()],500); }
