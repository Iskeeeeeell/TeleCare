<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
include __DIR__ . '/../db_connect.php';

$in   = json_decode(file_get_contents('php://input'), true) ?: [];
$pass = $in['password'] ?? '';
$role = ($in['role'] ?? '') === 'admin' ? 'admin' : 'resident';

if ($role === 'admin') {
    // Administrator: email + password
    $ident = strtolower(trim($in['email'] ?? ''));
    $stmt  = $conn->prepare("SELECT admin_id AS id, full_name, email, password_hash FROM admin WHERE email = ?");
} else {
    // Resident: Barangay ID number (given by the barangay) + password
    $ident = trim($in['barangay_id'] ?? '');
    $stmt  = $conn->prepare("SELECT resident_id AS id, full_name, email, password_hash FROM resident WHERE barangay_id = ?");
}

if ($ident === '' || $pass === '') {
    http_response_code(401);
    echo json_encode(['ok' => false]);
    exit;
}

$stmt->bind_param("s", $ident);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if ($row && password_verify($pass, $row['password_hash'])) {
    session_regenerate_id(true);
    $_SESSION['user'] = ['id' => $row['id'], 'role' => $role];
    echo json_encode(['ok' => true, 'user' => ['name' => $row['full_name'], 'email' => $row['email'], 'role' => $role]]);
} else {
    http_response_code(401);
    echo json_encode(['ok' => false]);
}
$conn->close();
